<?php

use Asymmetric\NotifyClient\NotifyClient;
use PHPUnit\Framework\TestCase;
use Asymmetric\NotifyClient\Environment;

class Test extends TestCase
{

    public function testCreateAesKey()
    {

        try {
            $publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtpNyjoP9pE6zmblJ4RJgC4RLIv7ptjC4f7sZKjjJqu7HRUbPG47QA6KacwRus1aOM8mc4yenhrCf4cJLJEaAFObmlmERH9du3j/+hBy3sQWwELuE+qrB5aQfE1D8zuhqCzrnABNuJNHOXwV/n9t0ZqoS187o2oTy7soOXFSGKG4g5sT/My4gtcxEikQhfjyVj2GvRqoeDS8VnuNK/cZTobggpOkv7aTbG7lpKsAqcnYsPohZbHF0i0mwEOu9m88y3UO3KgG07qF1JGjUW3iuS6MX05DRkKW229hbOCr2HrD+7KPmT2Uc1gcaUtjB5vnXqhvP8UNV5QNCGuE7hpbfnwIDAQAB";
            $transactionId = "NjI0NWU0NjkwZjZlOGIwMDA5ZjFiNWJk";
            $notifyClient = new NotifyClient(base64_decode($publicKey), $transactionId,  Environment::DEV);
            //$notifyClient = new NotifyClient(base64_decode($publicKey), $transactionId);
            //$notifyClient->setUrl("https://txagcsgcbf.execute-api.us-east-1.amazonaws.com/DEV/secureNotify");
            $notifyClient->setTimeOut(30);

            /*
            $headers = [
                'Content-Type' => 'application/json;',
                'accept-encoding' => 'application/json',
            ];

            $notifyClient->setHeaders($headers);
            */

            $response = $notifyClient->getTransaction();
            echo $response->getBody()->getContents();
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            echo $e->getResponse()->getBody();
        } catch (\GuzzleHttp\Exception\GuzzleException $e) {
            echo $e->getMessage();
        } catch (Exception $e) {
            echo $e->getMessage();
        }

    }

}
