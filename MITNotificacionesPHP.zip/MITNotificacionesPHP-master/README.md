# Sdk Php Client

Un conjunto de clases que permiten intercambiar mensajes de forma segura con los servicios de MIT.  
  
  
## Comenzando

Estas instrucciones te permitirán implementar el flujo de comunicación establecido en MIT para intercambio seguro de mensajes.
Basado en algoritmos de cifrado robusto.
 
 
## Pre-requisitos

0. php 7 o superior
 
 
## Modo de uso 

El SDK tiene como base los componentes de httpClient de la libreria Guzzle, PHP HTTP client.
Para mas información visite el siguiente enlace.

> Guzzle: https://docs.guzzlephp.org/en/stable/#

 
Pasos para usar la libreria.

1.- Inicializar el Objeto NotifyClient de la libreria como a continuacion se presenta.
    headers paramatro opcional.
```
    $notifyClient = new  NotifyClient(Entorno, publicKey, transactionId, headers = [])
```

2.- Opcionalmente se puede setear la url, timeout y agregar headers extra.

`$notifyClient->setUrl(URL_NOTIFICADOR);`

`$notifyClient->setTimeOut(30);`

`$headers = [
                 'Content-Type' => 'application/json;',
                 'accept-encoding' => 'application/json',
             ];
             $notifyClient->setHeaders($headers);`
             
             
3.- Llamar al postRequest que se encargara de procesar la transacción, a continación se presenta un ejemplo.


    $request = $notifyClient->getResponse();

Este metodo se encargara de regresar la respuesta desencriptada o un mensaje de error de producirse el mismo