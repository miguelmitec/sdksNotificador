<?php

namespace Asymmetric\NotifyClient\lib;

/**
 * Class Hmac
 * @package Asymmetric\NotifyClient\lib
 */
class Hmac
{
    private $algorithm;
    private $key;
    private $rawOutput;
    private $cStrong;

    const SHA256 = 'sha256';
    const LENGTH_KEY = 16;

    /**
     * Hmac constructor.
     * @param string $algorithm
     * @param bool $rawOutput
     */
    public function __construct($algorithm = self::SHA256, $rawOutput = true)
    {
        $this->cStrong  = true;
        $this->algorithm = $algorithm;
        $this->rawOutput = $rawOutput;
    }


    public static function createKey($length, $cStrong){
        return openssl_random_pseudo_bytes($length, $cStrong);
    }


    /**
     * @param $data
     * @return string
     */
    public function encode($data, $key = null)
    {
        try {
            return hash_hmac(
                $this->algorithm,
                $data,
                $key ? $key : $this->key,
                $this->rawOutput
            );
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $message
     * @param $expectedHmac
     * @param $hmacKey
     * @return bool
     * @throws \Exception
     */
    public static function verify($message, $expectedHmac, $hmacKey)
    {

        if (!isset($message)) {
            throw new \Exception("Message can't be null");
        }

        if (!isset($expectedHmac)) {
            throw new \Exception("Expected Hmac can't be null");
        }

        $receiveMessageHmac = (new Hmac)->encode($message, $hmacKey);

        if (strcasecmp(base64_encode($receiveMessageHmac), $expectedHmac) != 0) {
            throw new \Exception("Response Hmac not match");
        }
        return true;
    }
}
