<?php

namespace Asymmetric\NotifyClient\lib;

/**
 * Class KeysConverter
 * @package Asymmetric\NotifyClient\lib
 */
class KeysConverter
{

    /**
     * @param $publicKey
     * @return false|string
     */

    static function pemToDer($publicKey){
        $lines = explode("\n", trim($publicKey));
        unset($lines[count($lines)-1]);
        unset($lines[0]);
        $result = implode('', $lines);
        $result = base64_decode($result);
        return $result;
    }

    /**
     * @param $der
     * @param false $private
     * @return string
     */
    static function derToPem($der, $private=false)
    {
        $der = base64_encode($der);
        $lines = str_split($der, 64);
        $body = implode("\n", $lines);
        $title = $private? 'PRIVATE RSA KEY' : 'RSA PUBLIC KEY';
        $result = "-----BEGIN {$title}-----\n";
        $result .= $body . "\n";
        $result .= "-----END {$title}-----\n";
        return $result;
    }

}
