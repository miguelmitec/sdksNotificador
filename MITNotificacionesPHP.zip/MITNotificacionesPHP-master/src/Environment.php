<?php

namespace Asymmetric\NotifyClient;

/**
 * Class Environment
 * @package Asymmetric\NotifyClient
 *
 */
class Environment
{

    const DEV = 'dev';
    const PROD = 'prod';
    const QA = 'qa';
    const ENVIRONMENTS = [self::DEV, self::PROD, self::QA];
    private $environment;

    public function __construct($environment)
    {
        if(!in_array($environment, self::ENVIRONMENTS)){
            throw new \InvalidArgumentException("The environment is not recognized");
        }

        $_ENV['env'] = $environment;
    }

    /**
     * @return string|null
     */
    public static function getUrlKeys(){
        $url = null;
        switch ($_ENV['env']){
            case self::DEV:
                $url = "https://txagcsgcbf.execute-api.us-east-1.amazonaws.com/DEV/secureNotify";
                break;
            case self::PROD:
                $url = "https://txagcsgcbf.execute-api.us-east-1.amazonaws.com/DEV/secureNotify";
                break;
            case self::QA:
                $url = "https://txagcsgcbf.execute-api.us-east-1.amazonaws.com/DEV/secureNotify";
                break;
        }
        return $url;
    }

}
