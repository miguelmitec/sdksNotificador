<?php

namespace Asymmetric\NotifyClient\helpers;

/**
 * Class StorageHelper
 * @package Asymmetric\NotifyClient\helpers
 */
class StorageHelper
{
    private $aesKey;
    private $hmacKey;
    private $accessToken;
    private $rsaPublicKey;

    /**
     * TokenStorageHelper constructor.
     */
    public function __construct()
    {
    }

    /**
     * @param mixed $aesKey
     */
    public function setAesKey($aesKey)
    {
        $this->aesKey = $aesKey;
    }

    /**
     * @return mixed
     */
    public function getAesKey()
    {
        return $this->aesKey;
    }

    /**
     * @param mixed $hmacKey
     */
    public function setHmacKey($hmacKey)
    {
        $this->hmacKey = $hmacKey;
    }

    /**
     * @return mixed
     */
    public function getHmacKey()
    {
        return $this->hmacKey;
    }

    /**
     * @param mixed $rsaPublicKey
     */
    public function setRsaPublicKey($rsaPublicKey)
    {
        $this->rsaPublicKey = $rsaPublicKey;
    }

    /**
     * @return mixed
     */
    public function getRsaPublicKey()
    {
        return $this->rsaPublicKey;
    }

    /**
     * @param mixed $accessToken
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
    }

    /**
     * @return mixed
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

}
