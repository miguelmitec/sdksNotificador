<?php

namespace Asymmetric\NotifyClient;

use Asymmetric\NotifyClient\handlers\DeCypherResponse;
use Asymmetric\NotifyClient\helpers\StorageHelper;
use Asymmetric\NotifyClient\lib\KeysConverter;
use Asymmetric\NotifyClient\lib\RsaGenerator;
use Asymmetric\NotifyClient\lib\Aes;
use Asymmetric\NotifyClient\lib\Hmac;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Handler\CurlHandler;
use GuzzleHttp\HandlerStack;
use phpseclib3\Crypt\PublicKeyLoader;
use GuzzleHttp\Psr7;

/**
 * Class NotifyClient
 * @package Asymmetric\NotifyClient
 */
class NotifyClient
{

    private $publicKey;
    private $transactionId;
    private $storageHelper;
    private $environment;
    private $headers;
    private $url;
    private $timeout;

    /**
     * NotifyClient constructor.
     * @param $publicKey
     * @param $transactionId
     * @param $environment
     */
    public function __construct($publicKey, $transactionId, $environment = null)
    {
        $this->publicKey = $publicKey;
        $this->transactionId = $transactionId;
        $this->timeout = 30;


        $this->storageHelper = new StorageHelper();
        $this->storageHelper->setAesKey(Aes::createKey(32, true));
        $this->storageHelper->setHmacKey(Hmac::createKey(16, true));

        $rsaDerPublicKey = KeysConverter::derToPem($publicKey);
        $rsaPublicKey = PublicKeyLoader::load($rsaDerPublicKey);
        $this->storageHelper->setRsaPublicKey($rsaPublicKey);

        if (isset($environment)) {
            $this->environment = new Environment($environment);
            $this->url = $this->environment->getUrlKeys();
        }
    }

    /**
     * @return mixed
     * @throws \Exception
     * @throws GuzzleException
     */
    public function getTransaction()
    {
        $rsa = new RsaGenerator();
        $headers = [
            'Content-Type' => 'application/json;',
            'accept-encoding' => 'application/json',
        ];

        if (!isset($this->url)) {
            throw new \Exception("\nUrl Can not be null or empty");
        }

        if (!isset($this->timeout) || $this->timeout <= 0) {
            throw new \Exception("\nTimeout should be greater than 0");
        }

        if (isset($this->headers) && !is_array($this->headers)) {
            throw new \Exception("\nHeaders should be an array of type key => value");
        }

        if (isset($this->headers) && count($this->headers) > 0) {
            $headers = array_merge($headers, $this->headers);
        }


        try {
            $aes = $rsa->cypher($this->storageHelper->getAesKey(), $this->storageHelper->getRsaPublicKey());
            $hmac = $rsa->cypher($this->storageHelper->getHmacKey(), $this->storageHelper->getRsaPublicKey());

            $body = array(
                'hmacKey' => $hmac,
                'aesKey' => $aes,
                'id' => $this->transactionId
            );

            $stack = HandlerStack::create(new CurlHandler());
            $stack->push(new DeCypherResponse($this->storageHelper));
            $client = new Client(['handler' => $stack]);

            return $client->request('POST', $this->url, [
                'timeout' => $this->timeout,
                'headers' => $headers,
                'json' => $body
            ]);
        } catch (ClientException $e) {
            throw $e;
        }

    }

    /**
     * @param $url
     */
    public function setUrl($url)
    {
        $this->url = $url;
    }

    /**
     * @param $timeout
     */
    public function setTimeOut($timeout)
    {
        $this->timeout = $timeout;
    }

    /**
     * @param $headers
     */
    public function setHeaders($headers)
    {
        $this->headers = $headers;
    }

}