<?php


namespace Asymmetric\NotifyClient\handlers;

use Asymmetric\NotifyClient\helpers\StorageHelper;
use Asymmetric\NotifyClient\lib\Aes;
use Asymmetric\NotifyClient\lib\Hmac;
use Closure;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Psr7\Utils;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * Class DeCypherResponse
 * @package Asymmetric\NotifyClient\handlers
 */
class DeCypherResponse
{

    private $storageHelper;

    /**
     * DeCypherResponse constructor.
     * @param $storageHelper
     */
    public function __construct(StorageHelper $storageHelper)
    {
        $this->storageHelper = $storageHelper;
    }

    /**
     * @param callable $handler
     * @return Closure
     */
    public function __invoke(callable $handler)
    {
        return function (RequestInterface $request, array $options) use ($handler) {
            $promise = $handler($request, $options);
            return $promise->then(
                function (ResponseInterface $response) use ($request) {

                    $responseBody = $response->getBody()->getContents();
                    $responseJson = json_decode($responseBody);
                    $stream = Utils::streamFor($responseBody);
                    if(!isset($responseJson->aesCadResponse) || !isset($responseJson->hmacResponse)){
                        throw new ClientException("Bad Response Exception", $request, $response);
                        //return $response->withStatus(400)->withBody($stream);
                    }

                    $aesResponse = $responseJson->aesCadResponse;
                    $hmacResponse = $responseJson->hmacResponse;

                    $deCypherBody = Aes::deCypherData($aesResponse , $this->storageHelper->getAesKey());

                    $verify = Hmac::verify($deCypherBody, $hmacResponse, $this->storageHelper->getHmacKey());
                    $stream = Utils::streamFor($deCypherBody);
                    return $response->withBody($stream);
                }
            );
        };
    }
}
